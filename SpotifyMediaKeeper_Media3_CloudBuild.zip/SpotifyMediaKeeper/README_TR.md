# Spotify Media Keeper — deneysel Media3 prototipi

## Bu prototip ne yapar?
- Android Notification Listener izni üzerinden Spotify'ın aktif MediaSession bilgisini okur.
- Başlık, sanatçı, albüm ve varsa küçük albüm görselini kendi Media3 MediaSession oturumuna kopyalar.
- `onTaskRemoved()` içinde servisi durduran bir çağrı yoktur.

## Önemli sınırlamalar
- Bu uygulama Spotify'ın kendi servisini canlı tutmaz; ayrı bir medya oturumu yayınlar.
- Spotify oturumu tamamen kaybolduktan sonra oynat/duraklat/ileri/geri komutları Spotify'a yönlendirilmez. Bu prototipte bu komutlar gerçek Spotify oynatmasını kontrol etmez.
- Servisin uygulama son görevlerden kaydırıldıktan sonra her koşulda ve sonsuza kadar yaşayacağı garanti edilemez. Android süreçleri bellek ve güç politikaları nedeniyle sonlandırabilir. Media3'ün standart servis yaşam döngüsü de duraklatılmış/boş oturumlarda servisin kapanmasına izin verir.
- Bu ilk sürüm derleme ve cihaz uyumluluğu denemesi içindir; Dynamic Island ile çalışması garanti değildir. Dynamic Island'ın aktif medya oturumlarını nasıl seçtiği ayrıca test edilmelidir.
- Android 11 / One UI 3.1 hedef cihazda test edilmelidir.

## Kurulum
1. APK'yı yükle.
2. Uygulamayı aç ve Bildirim erişimi ayarlarından Spotify Media Keeper'a izin ver.
3. Spotify'da bir parça başlat.
4. Uygulamaya dönüp Medya servisini başlat düğmesine bas.
5. Hızlı panelde ve Dynamic Island'da yeni medya oturumunun görünüp görünmediğini kontrol et.

## Bulut derleme
Repository köküne bu proje dosyalarını ve `.github/workflows/build-apk.yml` dosyasını koy. GitHub Actions iş akışı manuel olarak çalıştırıldığında APK artifact olarak yayınlanır.
