package com.example.spotifymediakeeper;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.service.notification.NotificationListenerService;
import android.content.ComponentName;
import android.os.Build;
import android.os.Bundle;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class SpotifySessionListener extends NotificationListenerService {
    private static final String SPOTIFY = "com.spotify.music";
    private MediaSessionManager manager;
    private MediaSessionManager.OnActiveSessionsChangedListener sessionsListener;

    @Override public void onListenerConnected() {
        super.onListenerConnected();
        manager = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
        sessionsListener = controllers -> inspect(controllers);
        try {
            manager.addOnActiveSessionsChangedListener(sessionsListener,
                    new ComponentName(this, SpotifySessionListener.class));
            inspect(manager.getActiveSessions(new ComponentName(this, SpotifySessionListener.class)));
        } catch (SecurityException ignored) { }
    }

    @Override public void onListenerDisconnected() {
        if (manager != null && sessionsListener != null) {
            try { manager.removeOnActiveSessionsChangedListener(sessionsListener); } catch (Exception ignored) {}
        }
        super.onListenerDisconnected();
    }

    private void inspect(List<MediaController> controllers) {
        if (controllers == null) return;
        for (MediaController c : controllers) {
            if (!SPOTIFY.equals(c.getPackageName())) continue;
            MediaMetadata m = c.getMetadata();
            if (m == null) return;
            String title = m.getString(MediaMetadata.METADATA_KEY_TITLE);
            String artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST);
            String album = m.getString(MediaMetadata.METADATA_KEY_ALBUM);
            Bitmap art = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
            if (art == null) art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
            byte[] artBytes = null;
            if (art != null) {
                Bitmap small = Bitmap.createScaledBitmap(art, 128, 128, true);
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                small.compress(Bitmap.CompressFormat.JPEG, 75, out);
                artBytes = out.toByteArray();
            }
            PlaybackState state = c.getPlaybackState();
            boolean playing = state != null && state.getState() == PlaybackState.STATE_PLAYING;
            Intent update = new Intent(MirrorMediaSessionService.ACTION_UPDATE);
            update.setPackage(getPackageName());
            update.putExtra("title", title == null ? "Bilinmeyen parça" : title);
            update.putExtra("artist", artist == null ? "" : artist);
            update.putExtra("album", album == null ? "" : album);
            update.putExtra("playing", playing);
            if (artBytes != null) update.putExtra("art", artBytes);
            sendBroadcast(update);
            return;
        }
    }
}
