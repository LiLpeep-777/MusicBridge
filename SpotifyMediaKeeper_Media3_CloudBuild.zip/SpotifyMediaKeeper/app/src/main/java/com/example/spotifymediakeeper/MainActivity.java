package com.example.spotifymediakeeper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);

        TextView info = new TextView(this);
        info.setText("Spotify Media Keeper (deneysel)\n\n1) Bildirim erişimini aç.\n2) Spotify'da bir şarkı başlat.\n3) Bu uygulamaya dönüp servisi başlat.\n\nBu prototip Spotify oturumundan bilgileri kopyalayıp ayrı bir Media3 oturumu yayınlar. Spotify kapatıldıktan sonra son metadata korunabilir. Oynatma düğmelerinin Spotify'a aktarılması henüz desteklenmez.");
        layout.addView(info);

        Button permission = new Button(this);
        permission.setText("Bildirim erişimi ayarlarını aç");
        permission.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        layout.addView(permission);

        Button start = new Button(this);
        start.setText("Medya servisini başlat");
        start.setOnClickListener(v -> {
            Intent i = new Intent(this, MirrorMediaSessionService.class);
            // Target SDK 30 prototype: start while Activity is foreground.
            // Media3 promotes the service when actual playback is ongoing.
            startService(i);
        });
        layout.addView(start);

        setContentView(layout);
    }
}
