package com.example.spotifymediakeeper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

public class MirrorMediaSessionService extends MediaSessionService {
    public static final String ACTION_UPDATE = "com.example.spotifymediakeeper.UPDATE";
    private ExoPlayer player;
    private MediaSession mediaSession;
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { applyUpdate(intent); }
    };

    @Override public void onCreate() {
        super.onCreate();
        player = new ExoPlayer.Builder(this).build();
        mediaSession = new MediaSession.Builder(this, player).build();
        IntentFilter filter = new IntentFilter(ACTION_UPDATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter);
    }

    private void applyUpdate(Intent intent) {
        String title = intent.getStringExtra("title");
        String artist = intent.getStringExtra("artist");
        String album = intent.getStringExtra("album");
        byte[] art = intent.getByteArrayExtra("art");

        MediaMetadata.Builder metadata = new MediaMetadata.Builder()
                .setTitle(title == null ? "Bilinmeyen parça" : title)
                .setArtist(artist == null ? "" : artist)
                .setAlbumTitle(album == null ? "" : album);
        if (art != null && art.length > 0) {
            metadata.setArtworkData(art, MediaMetadata.PICTURE_TYPE_FRONT_COVER);
        }

        MediaItem item = new MediaItem.Builder()
                .setMediaId("spotify-mirror")
                .setMediaMetadata(metadata.build())
                .build();
        player.setMediaItem(item);
        player.prepare();
        player.pause();
    }

    @Nullable @Override public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }

    // Deliberately do not stop the mirror service when the app task is swiped away.
    @Override public void onTaskRemoved(@Nullable Intent rootIntent) {
        // Intentionally empty. Android may still reclaim the process under system pressure/policy.
    }

    @Override public void onDestroy() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        if (mediaSession != null) { mediaSession.release(); mediaSession = null; }
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }
}
